AROMA OF UTKALA — WEBSITE STARTER

FILES
- index.html: responsive website with product enquiry/cart, English/Odia text toggle and WhatsApp order handoff.
- assets/kendujhar-badi-women.jpg: generated brand image based on your requested Kendujhar Badi village scene.

IMPORTANT BEFORE GOING LIVE
1. Open index.html in a browser to preview.
2. WhatsApp is configured as +91 89175 99198.
3. Sample pack prices currently shown for each variety: 100g ₹99, 250g ₹249 and 500g ₹459. Confirm these apply to every variety before publishing. Replace sample product names/descriptions with your actual varieties.
4. Add your real prices, pack weights, ingredient list, FSSAI details, business address and delivery policy before accepting orders.
5. The cart sends an enquiry/order list to WhatsApp; it does not take online payments or calculate shipping. A payment gateway and backend are needed for full ecommerce checkout.
6. Add real product photographs when available. The generated village photo is illustrative, not documentary evidence of your production process.

EXTERNAL HERITAGE PHOTO CREDITS / LICENSE LINKS
- Konark Sun Temple: Maina Tudu, Wikimedia Commons, CC0 1.0.
  https://commons.wikimedia.org/wiki/File:Sun_Temple_Konark_Odisha.jpg
- Jagannath Temple, Puri: Subashdas123, Wikimedia Commons, CC0 1.0.
  https://commons.wikimedia.org/wiki/File:Jagannath_temple_Puri.jpg
- Chilika Lake: Avik adhikari, Wikimedia Commons file page (check current license details before reuse/redistribution).
  https://commons.wikimedia.org/wiki/File:Chilika_Lake_of_Odisha.jpg

CULTURE / FACT CHECK SOURCES
- Odisha Tourism — overview, history and living traditions:
  https://odishatourism.gov.in/en/odisha-at-a-glance
- Odisha Tourism — heritage architecture:
  https://odishatourism.gov.in/en/heritage-architecture
- Odisha Tourism — arts, crafts and handlooms:
  https://odishatourism.gov.in/en/arts-crafts-handloom
- Odisha Tourism — festivals:
  https://odishatourism.gov.in/en/festival-celebrations

The Badi history section is intentionally cautious: it describes a living pulse-preservation food tradition and does not invent a founding date or a single inventor.

FREE WEBSITE ADDRESS
A free hosting subdomain can be used with GitHub Pages (for example, your chosen GitHub username.github.io). No custom domain has been registered or deployed from this package. Publish the site through a GitHub account to activate a free address; custom domains usually cost money.
